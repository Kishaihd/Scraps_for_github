#!/bin/bash

./sign_cli.py -i 10
./sign_cli.py -c 20 120 90

for i in 2 3 4 5 6 7 8 9
do
  ./sign_cli.py -i $i

  #for j in 1 2 3 4 5 6 7 8 9
  #do
  #  ./sign_cli.py -i $j

  #  #sleep 0.2
  #done

  #sleep 0.2
done

for i in 8 7 6 5 4 3 2
do
  ./sign_cli.py -i $i

  #for j in 1 2 3 4 5 6 7 8 9
  #do
  #  ./sign_cli.py -i $j

  #  #sleep 0.2
  #done

  #sleep 0.2
done
