#!/usr/bin/python3
import RPi.GPIO as GPIO
from time import sleep
GPIO.setmode(GPIO.BCM)

led_red = 18

GPIO.setup(led_red, GPIO.OUT)


def fadeIt(pwm, start, end, step=2):
		if start > end:
			step *= -1
			end -= 1
		else: 
			end += 1
		for duty in range(start, end, step):
			pwm.ChangeDutyCycle(duty)
			sleep(0.1)



#for _ in range(10):
#	GPIO.setup(led_red, not GPIO.input(led_red))
#	sleep(1.0)
#GPIO.cleanup()


pwm = GPIO.PWM(led_red, 50)
pwm.start(0)
for _ in range (2):
	fadeIt(pwm, 0, 100)
	fadeIt(pwm, 100, 0)
GPIO.cleanup()
