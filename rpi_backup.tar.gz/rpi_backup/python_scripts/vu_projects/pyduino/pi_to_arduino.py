#!/usr/bin/python3
# import os
# import json
import serial  # For use on Raspberry Pi
import smbus   # RPi
import time
import re
import sys
import getopt


# Necessary?
# bus1 = smbus.SMBus(1)
# bus2 = smbus.SMBus(1)

# What is love?
aaddress1 = 0x04
aaddress2 = 0x06

# Baby don't hurt me.
port1 = serial.Serial("/dev/ttyAMA0", baudrate=9600, timeout=1)
port2 = serial.Serial("/dev/ttyAMA1", baudrate=9600, timeout=1)


def main(argv):
    # if argv.__sizeof__() <= 2:
    #     print("Need more arguments!")
    #     sys.exit()
    try:
        opts, args = getopt.getopt(argv, "hr:g:b:rgb:c:i:n:", ["help", "red", "blue", "green", "rgb",  "colors", "brightness", "on", "off", "new"])
    except getopt.GetoptError:
        print("Error!")
        sys.exit(2)
    for opt, arg in opts:
        if opt in ("-h", "--help", "", " "):
            print('''=========================
|\t  Usage:\t|\n=========================
-h  --help\t Print this menu\n    --on\t Turn the lights on, using previous settings
    --off\t Turn the lights off \n-r  --red\t Adjust only red\n-b  --blue\t Adjust only blue
-g  --green\t Adjust only green\n-c  --colors\t Set all three colors (e.g. ff0b1f, or 255 11 31
-i  --brightness Intensity/brightness (0 - 255)\n-n  --new\t Enter new configuration (rgb br)''')
            sys.exit()
        else:
            red = 000
            blue = 000
            green = 000
            brightness = 000
            value = 000000  # This is the formatted number value, in case the user sucks at typing numbers.(cut erroneous chars out)

            config = {
                "red": red,
                "green": green,
                "blue": blue,
                "brightness": brightness
            }
            print("Opening default config file...\n")
            file = open('.lights.config.txt', 'r')
            try:
                print(file.read())
                for line in file:
                    # print(line)
                    val = line.split()
                    try:
                        config[str(val[0])] = int(val[1])
                    except:
                        config[str(val[0])] = int(val[1], 16)
                # print(config)
                file.close()
                file = open('.lights.config.txt', 'w')
            except:
                file.close()
                print("Config file was empty.")
                file = open('.lights.config.txt', 'w')
                # print(config)
            # Begin checking cli arguments passed in.
            if opt in "--on":
                print("ON!")
                # bus1.write_byte_data(aaddress1, 1)
                port1.write("Ping pong ON!")
            elif opt in "--off":
                print("OFF!")

            elif opt in ("-r", "--red"):
                print("Adjusting red...\nRed is {0}".format(arg))
                print(type(config))
                print(type(arg))
                red = int(arg)
                print(type(red))
                config["red"] = int(red)
            elif opt in ("-g", "--green"):
                print("Adjusting green...\nGreen is {0}".format(arg))
                green = int(arg)
                config["green"] = green
            elif opt in ("-b", "--blue"):
                print("Adjusting blue...\nBlue is {0}".format(arg))
                blue = int(arg)
                config["blue"] = blue
            elif opt in ("-c", "--colors"):
                print("Changing colors...")
                print(sys.argv[2])
                print(sys.argv[3])
                print(sys.argv[4])
                config["red"] = int(sys.argv[2])
                config["green"] = int(sys.argv[3])
                config["blue"] = int(sys.argv[4])
            elif opt in ("-i", "--brightness"):
                print("Adjusting brightness...\nBrightness is {0}".format(arg))
                brightness = arg
                config["brightness"] = brightness
            elif opt in ("-n", "--new"):
                print("Creating new configurations...")
                try:  # Success indicates color values are base 10.
                    test = sys.argv[5]
                    print("Red: {0}".format(sys.argv[2]))
                    print("Green: {0}".format(sys.argv[3]))
                    print("Blue: {0}".format(sys.argv[4]))
                    print("Brightness: {0}".format(sys.argv[5]))
                    config["red"] = sys.argv[2]
                    config["green"] = sys.argv[3]
                    config["blue"] = sys.argv[4]
                    config["brightness"] = sys.argv[5]
                except:  # Exception indicates color values are base 16.
                    print(sys.argv[2])
                    tred = "0x{0}".format(sys.argv[2][0:2])
                    print("Red is: {0}".format(tred))
                    print("Red is: {0}".format(int(tred, 16)))
                    tgreen = "0x{0}".format(sys.argv[2][2:4])
                    print("Green is: {0}".format(tgreen))
                    print("Green is: {0}".format(int(tgreen, 16)))
                    tblue = "0x{0}".format(sys.argv[2][4:])
                    print("Blue is: {0}".format(tblue))
                    print("Blue is: {0}".format(int(tblue, 16)))
            # print(config)
            for k, v in config.items():
                # print(k)
                file.write(str(k))
                file.write(" ")
                # print(v)
                # test_hex = hex(int(v))  # Convert int to hex.
                # print(hex(int(v)))
                # test_int = int(test_hex, 16)  # Convert hex to int.
                # print(test_int)
                file.write(str(v))
                file.write("\n")
            file.close()

# print("{0},{1}".format((len(sys.argv) - 1), str(sys.argv[1:])))
if __name__ == "__main__":
    test = sys.argv[1:]
    # print(test)
    # print(len(test))
    if len(test) < 1:
        # print("fuck!")
        test = ['-h']
    main(test)
    # main(sys.argv[1:])





# def txData(data):
#     bus1.write_byte_data(aaddress1, data)
#     return -1
#
#
# def rxData():
#     rxdat = bus1.read_byte_data(aaddress1)
#     return rxdat
#
# def rxDat2():
#
#     while True:
#         var = input("")
#         if not var:
#             continue
#
#         txData(var)
#         data = rxData()

# Reading data from a port, method 2 using port designators.
def rx_data():
    while True:
        data_in = port1.read()
        if len(data_in) == 0:
            break
        sys.stdout.write(data_in)
    sys.stdout.write('\n')

# Not strictly necessary to write this function, but I want the code to be uniform and clear.
def dec_to_hex(dec_val):
    hex_val = hex(int(dec_val))
    return hex_val

# Not strictly necessary to write this function, but I want the code to be uniform and clear.
def hex_to_dec(hex_val):
    dec_val = int(hex_val, 16)
    return dec_val


