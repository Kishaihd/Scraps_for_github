#!/usr/bin/python3
# import os
# import json
import re
import sys
import getopt


def main(argv):
    # if argv.__sizeof__() <= 2:
    #     print("Need more arguments!")
    #     sys.exit()
    try:
        opts, args = getopt.getopt(argv, "hr:g:b:rgb:c:i:n:", ["help", "red", "blue", "green", "rgb",  "colors", "brightness", "on", "off", "new"])
    except getopt.GetoptError:
        print("Error!")
        sys.exit(2)
    for opt, arg in opts:
        if opt in ("-h", "--help", "", " "):
            print('''=========================
|\t  Usage:\t|\n=========================
-h  --help\t Print this menu\n    --on\t Turn the lights on, using previous settings
    --off\t Turn the lights off \n-r  --red\t Adjust only red\n-b  --blue\t Adjust only blue
-g  --green\t Adjust only green\n-c  --colors\t Set all three colors (e.g. ff0b1f, or 255 11 31)
-i  --brightness Intensity/brightness (0 - 255)\n-n  --new\t Enter new configuration (rgb br)''')
            sys.exit()
        else:
            red = 000
            blue = 000
            green = 000
            brightness = 000
            value = 00000000  # This is the formatted number value, in case the user sucks at typing numbers.(cut erroneous chars out)

            config = {
                "red": red,
                "green": green,
                "blue": blue,
                "brightness": brightness
            }
            
            print("Opening default config file...\n")
            #try:
            #    file = open('.lights.config.txt', 'r')
            #except:
            #    file = open('.lights.config.txt', 'w')
            try:
                file = open('.lights.config.txt', 'r')
                #print("File contents:")
                #print(file.read())
                #print("Printing each line")
                for line in file:
                    #print("for line in file:")
                    #print(line)
                    val = line.split()
                    #print(val[0])
                    #print(val[1])
                    config[str(val[0])] = val[1]
                #print("printing config")    
                #print(config)
                print("Previous Configuration:")
                file.close()
                file = open('.lights.config.txt', 'r')
                print(file.read())
                file.close()
                file = open('.lights.config.txt', 'w')
            except:
                file.close()
                print("Config file was empty.")
                file = open('.lights.config.txt', 'w')
            if opt in "--on":
                print("ON!") # Turns on at half brightness, so as not to assault your occular nerves.
                config["brightness"] = 127
            elif opt in "--off":
                print("OFF!")
                config["brightness"] = 0
            elif opt in ("-r", "--red"):
                print("Adjusting red...\nRed is {0}".format(arg))
                print(type(config))
                print(type(arg))
                red = int(arg)
                print(type(red))
                config["red"] = int(red)
            elif opt in ("-g", "--green"):
                print("Adjusting green...\nGreen is {0}".format(arg))
                green = int(arg)
                config["green"] = green
            elif opt in ("-b", "--blue"):
                print("Adjusting blue...\nBlue is {0}".format(arg))
                blue = int(arg)
                config["blue"] = blue
            elif opt in ("-c", "--colors"):
                try: # Success indicates values are base 10.
                    test = sys.argv[3]
                    print("Changing colors...")
                    print(sys.argv[2])
                    print(sys.argv[3])
                    print(sys.argv[4])
                    config["red"] = int(sys.argv[2])
                    config["green"] = int(sys.argv[3])
                    config["blue"] = int(sys.argv[4])
                except: # Else base 16!
                    print(sys.argv[2])
                    hred = "0x{0}".format(sys.argv[2][0:2])
                    print("Red hex: {0}".format(hred))
                    print("Red dec: {0}".format(int(hred, 16)))
                    hgreen = "0x{0}".format(sys.argv[2][2:4])
                    print("Green hex: {0}".format(hgreen))
                    print("Green dec: {0}".format(int(hgreen, 16)))
                    hblue = "0x{0}".format(sys.argv[2][4:6])
                    print("Blue hex: {0}".format(hblue))
                    print("Blue dec: {0}".format(int(hblue, 16)))
            elif opt in ("-i", "--brightness"):
                print("Adjusting brightness...\nBrightness is {0}".format(arg))
                brightness = arg
                config["brightness"] = brightness
            elif opt in ("-n", "--new"):
                print("Creating new configurations...")
                try: # Success indicates color and brightness values are base 10.
                    test = sys.argv[4] # Only checking last color, rather than brightness, in case of user stupidity.
                    print("Red: {0}".format(sys.argv[2]))
                    print("Green: {0}".format(sys.argv[3]))
                    print("Blue: {0}".format(sys.argv[4]))
                    try:
                        print("Brightness: {0}".format(sys.argv[5]))
                    except:
                        print("Brightness: {0}".format(config["brightness"]))
                    config["red"] = sys.argv[2]
                    config["green"] = sys.argv[3]
                    config["blue"] = sys.argv[4]
                    try:
                        config["brightness"] = sys.argv[5]
                    except:
                        # No change to brightness. User is duuuumb.
                        config["brightness"] = 0
                except: # Exception indicates color values are base 16.
                    print(sys.argv[2])
                    hred = "0x{0}".format(sys.argv[2][0:2])
                    print("Red hex: {0}".format(hred))
                    print("Red dec: {0}".format(int(hred, 16)))
                    hgreen = "0x{0}".format(sys.argv[2][2:4])
                    print("Green hex: {0}".format(hgreen))
                    print("Green dec: {0}".format(int(hgreen, 16)))
                    hblue = "0x{0}".format(sys.argv[2][4:6])
                    print("Blue hex: {0}".format(hblue))
                    print("Blue dec: {0}".format(int(hblue, 16)))
                    try: # Is user dumb? 
                        test = sys.argv[2][6:8]
                        #print(test)    
                        hbright = "0x{0}".format(sys.argv[2][6:])
                    except: # Yes. User is dumb.
                        hbright = "0x00"
                    print("Brightness hex: {0}".format(hbright))
                    print("Brightness dec: {0}".format(int(hbright, 16)))    
                    
                    config["red"] = int(hred, 16)
                    config["green"] = int(hgreen, 16)
                    config["blue"] = int(hblue, 16)
                    try:
                        config["brightness"] = int(hbright, 16)
                    except:
                        # No change to brightness. User is duuuumb.
                        config["brightness"] = 0
            print(config)
            c2 = "{0}{1}{2}{3}".format(hex(int(config["red"])),hex(int(config["green"])),hex(int(config["blue"])),hex(int(config["brightness"])))
            c1 = "{0}{1}{2}{3}".format(int(config["red"]),int(config["green"]),int(config["blue"]),int(config["brightness"]))
            print("Config as one hex string: {0}".format(c2))        
            print("Config as one dec string: {0}".format(c1))
            # print(config)
            for k, v in config.items():
                # print(k)
                file.write(str(k))
                file.write(" ")
                # print(v)
                # test_hex = hex(int(v))  # Convert int to hex.
                # print(hex(int(v)))
                # test_int = int(test_hex, 16)  # Convert hex to int.
                # print(test_int)
                file.write(str(v))
                file.write("\n")
            file.close()

# print("{0},{1}".format((len(sys.argv) - 1), str(sys.argv[1:])))
if __name__ == "__main__":
    test = sys.argv[1:]
    # print(test)
    # print(len(test))
    if len(test) < 1:
        # print("fuck!")
        test = ['-h']
    main(test)
    # main(sys.argv[1:])
