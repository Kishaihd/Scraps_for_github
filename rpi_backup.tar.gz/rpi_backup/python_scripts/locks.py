#!/usr/bin/python3
import logging
import threading
import time

#logging.basicConfig(level=logging.INFO, format="%(asctime)s (T:%(thread)d):-%(message)s")

class MessagePrinter(threading.Thread):
	def __init__(self, *args, **kwargs):
		threading.Thread.__init__(self)
		self._args = args
		self._kwargs = kwargs
		self._lock = kwargs.get("lock", None)
	def run(self):
		for message in self._args:
			if self._lock:
				self._lock.acquire()
			print(message)
			if self._lock:
				self._lock.release()
			time.sleep(self._kwargs.get("delay", 1.0))

lock = threading.Lock()
mp1 = MessagePrinter("Hello", "Good day!", lock=lock)
mp2 = MessagePrinter("A", "B", "C", delay=3, lock=lock)
mp1.start()
mp2.start()
mp1.join()
mp2.join()
